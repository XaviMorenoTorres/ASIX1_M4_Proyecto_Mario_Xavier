<?php
session_start();

if (!isset($_SESSION["pantalla2"]) || !$_SESSION["pantalla2"]) {
    header("Location: pantalla2.php");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre_personaje = $_POST["nombre_personaje"];
    $nombre_circuito = $_POST["nombre_circuito"];
    $evolucion = $_POST["evolucion"];

    // Validar respuestas
    if ($nombre_personaje == "Toad" && $nombre_circuito == "Circuito Toad" && $evolucion == "ivysaur") {
        // Respuestas correctas, almacenar en sesión
        $_SESSION["pantalla3"] = true;
        header("Location: pantalla4.php");
    } else {
        // Respuestas incorrectas, proporcionar pista
        echo "<br>Pista: Es un personaje pequeño y tiene una forma de hongo. ¿Quién es?<br><br>";
        echo '<img class="img1" src="../IMG/logo_DK.jpg" alt="Donkey Kong Logo">';
        echo "<body style='background-color: #663e0d;'>";
        echo "</body>";
    }    
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Pantalla 3</title>
    <link rel="stylesheet" href="../css/estilos.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
</head>
<body>
    <h1>Tiene una cabeza grande y redonda</h1>
    <form method="post">
        <label for="nombre_personaje">Nombre del personaje:</label>
        <input type="text" name="nombre_personaje" required><br>
        <label for="nombre_circuito">Nombre de su circuito:</label>
        <input type="text" name="nombre_circuito" required><br>
        <label for="evolucion">Evolución:</label>
        <input type="text" name="evolucion" required><br>
        <input type="submit" value="Enviar">
    </form>
</body>
</html>

